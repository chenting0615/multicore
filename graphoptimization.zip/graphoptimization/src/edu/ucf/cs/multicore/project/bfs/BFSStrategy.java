package edu.ucf.cs.multicore.project.bfs;

import edu.ucf.cs.multicore.project.model.Node;

public interface BFSStrategy {
	
	public void runBFS(Node srouce, Node dest);

}
