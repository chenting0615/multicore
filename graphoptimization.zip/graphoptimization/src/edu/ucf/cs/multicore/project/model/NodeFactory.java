package edu.ucf.cs.multicore.project.model;


public interface NodeFactory {
	
	public Node createNode(Integer index, String label);

}
